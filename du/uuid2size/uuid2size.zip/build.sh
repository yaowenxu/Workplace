#!/bin/bash
g++ GetSpaceSizeByUUIDs.cc -o run
